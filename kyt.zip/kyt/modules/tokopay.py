from kyt import *

admin_chat_id = 5886670360

# Fungsi untuk menambahkan saldo
def add_saldo(nomor, amount):
    db = get_db()
    db.execute("UPDATE user SET saldo = saldo + ? WHERE member = ?", (amount, nomor))
    db.commit()

# Fungsi untuk mendapatkan timestamp expired
def expired_ts():
    return int(time.time()) + 2 * 60  # Ubah waktu kedaluwarsa menjadi 2 menit

# State untuk percakapan
class States:
    WAITING_FOR_AMOUNT = 0

@bot.on(events.CallbackQuery(data=b'tokopay'))
async def start_deposit(event):
    sender = await event.get_sender()
    nomor = sender.id

    async with bot.conversation(event.chat_id) as conv:
        await conv.send_message("Silakan masukkan jumlah deposit:")
        try:
            response = await conv.get_response(timeout=120)  # Tambahkan timeout
        except asyncio.TimeoutError:
            await conv.send_message("Waktu habis. Silakan mulai ulang proses deposit.")
            return

        try:
            amount = int(response.text)
            if amount < 100:
                await conv.send_message("Minimal deposit 2000 ka :)")
                return
        except ValueError:
            await conv.send_message("Jumlah yang Anda masukkan tidak valid. Silakan masukkan angka.")
            return

        val = valid(sender.id)
        ref_id = 'SF-' + hashlib.md5(str(time.time()).encode()).hexdigest()
        signature = hashlib.md5(f"{MerchantID}:{SecretKey}:{ref_id}".encode()).hexdigest()

        request_data = {
            'merchant_id': MerchantID,
            'kode_channel': 'QRIS',
            'reff_id': ref_id,
            'amount': amount,
            'customer_name': sender.first_name,
            'customer_email': val["email"],
            'customer_phone': nomor,
            'redirect_url': f"https://tokopay.id/trx/{ref_id}",
            'expired_ts': expired_ts(),
            'signature': signature,
            'items': [
                {
                    'product_code': 'DEPOSIT',
                    'name': 'Deposit SF Store',
                    'price': amount,
                    'product_url': 'https://instagram.com/muhamadripal26_',
                    'image_url': 'https://instagram.com/muhamadripal26_',
                },
            ],
        }

        try:
            post = requests.post('https://api.tokopay.id/v1/order', json=request_data)
            response = post.json().get('data')
            if not response:
                await conv.send_message("Gagal membuat order. Silakan coba lagi nanti.")
                return

            qr_link = response.get('qr_link')
            pay_url = response.get('pay_url')
            admin = 100
            persen = 0.7 / 100
            fee = admin + amount * persen

            capt = (f"""
**───〔 __DEPOSIT__ 〕───**
**» Trx Id :** `{response['trx_id']}`
**» Total Bayar :** `{response['total_bayar']}`
**» Total Diterima :** `{response['total_diterima']}`
**» Fee :** `{fee}`
**» Status :** `Unpaid`
**» Qr Link :** `{qr_link}`
**» Expired :** `2 menit`
**────────────────**
** NOTE :**
__Jika kalian sudah membayar tapi saldo belum bertambah silahkan hubungi ke @abecasdee13 lalu kirim bukti pembayaran nya kalo saldo belum masuk selama 5 menit__
**────────────────**
""")

            if qr_link:
                await bot.send_file(event.chat_id, qr_link, caption=capt, buttons=[
                    [Button.url("Lanjutkan Pembayaran", pay_url)],
                    [Button.url("Admin Kontak", "https://t.me/abecasdee13")]
                ])

            # Memantau pembayaran hingga status berubah menjadi "Success" atau waktu kedaluwarsa
            start_time = time.time()
            while time.time() - start_time < 2 * 60:  # Memeriksa setiap 10 detik selama 2 menit
                new_post = requests.post('https://api.tokopay.id/v1/order', json=request_data)
                res = new_post.json().get('data')

                if res and res.get('status') == 'Success':
                    add_saldo(nomor, res['total_diterima'])
                    capt = (f"""
**───〔 __SUCCESS__ 〕───**
**» Trx Id :** `{res['trx_id']}`
**» Total Diterima :** `{res['total_diterima']}`
**» Fee :** `{fee}`
**» Total Bayar :** `{res['total_bayar']}`
**» Status :** `Paid`
**────────────────**
""")
                    await bot.send_message(event.chat_id, capt)
                    
                    # Kirim notifikasi ke admin
                    admin_capt = (f"""
**───〔 __TOPUP TOKOPAY__ 〕───**
**  INFO USER TOPUP :**
**» Name :** `{sender.first_name}`
**» User ID :** `{nomor}`
**» Email :** `{val["email"]}`
**» Trx Id :** `{res['trx_id']}`
**» Total Diterima :** `{res['total_diterima']}`
**» Total Bayar :** `{res['total_bayar']}`
**────────────────**
""")
                    await bot.send_message(admin_chat_id, admin_capt)
                    break

                await asyncio.sleep(10)  # Menunggu 10 detik sebelum pemeriksaan berikutnya

            else:
                await conv.send_message("Waktu pembayaran sudah habis. Silakan coba lagi.")
                
        except Exception as e:
            await event.reply(f"Error: {str(e)}")