from kyt import *

@bot.on(events.CallbackQuery(data=b'lihat_ip'))
async def lihat_ip(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = sender.id

    vps_ips = get_user_vps_ips(user_id)
    if vps_ips:
        msg = "**Daftar IP VPS Anda:**\n\n"
        msg += "               IP VPS                      |  EXPIRED\n"
        msg += "-" * 63 + "\n"
        for ip, expiry in vps_ips:
            msg += f"`{ip.ljust(20)}` | {expiry}\n"
    else:
        msg = "Anda tidak memiliki IP VPS yang terdaftar."

    # Mengedit pesan yang sudah ada dengan msg baru
    # Simulasi edit pesan
    await event.edit(msg, buttons=[[Button.inline("Back To Menu", "menu")]])