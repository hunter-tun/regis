from kyt import *

@bot.on(events.CallbackQuery(data=b'list_users'))
async def list_users(event):
    conn = sqlite3.connect('kyt/database_regis.db')
    c = conn.cursor()
    c.execute('SELECT saldo, member, email FROM user')
    users = c.fetchall()
    conn.close()
    
    message = '**Daftar Pengguna Bot:**\n\n'
    for user in users:
        message += (f"**◇ Saldo :** Rp.`{user[0]}`\n"
                    f"**◇ Member :** `{user[1]}`\n"
                    f"**◇ Email :** `{user[2]}`\n\n")
    
    await event.edit(message, buttons=[Button.inline("Menu","menu")])