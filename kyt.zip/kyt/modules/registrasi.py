from kyt import *
import re

@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasie(event):
    async def registrasie_(event):
        user = generate_random_username()

        async with bot.conversation(chat) as pw_conv:
            await event.edit("**Input IP VPS:**\nKetik /cancel untuk membatalkan")
            pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))

            if pw_msg.raw_text == "/cancel":
                await event.respond("""Proses registrasi dibatalkan.""",buttons=[[Button.inline("Menu","menu")]])
                return

            pw = pw_msg.raw_text
        
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Expiry Day**", buttons=[
                [Button.inline(" 30 Day : 10K ", "30"), Button.inline(" 60 Day : 20K ", "60")]
            ])
            exp_cb = await exp_conv.wait_event(events.CallbackQuery)

            if exp_cb.data.decode("ascii") == "/cancel":
                await event.respond("""Proses registrasi dibatalkan.""",buttons=[[Button.inline("Menu","menu")]])
                return

            exp = exp_cb.data.decode("ascii")

        # Set harga berdasarkan expiry day
        harga = {"30": 10000, "60": 20000}.get(exp, 0)
        expiry_days = int(exp)  # Jumlah hari masa aktif

        # Check saldo user
        user_id = sender.id
        saldo_user = check_saldo(user_id)

        if saldo_user >= harga:
            # Potong saldo
            update_saldo(user_id, saldo_user - harga)
            
            # Add VPS IP to the database
            add_vps_ip(user_id, pw, expiry_days)

            cmd = f'python3 /root/add-ip.py "{pw}" "{user}" "{exp}"'
            try:
                result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            except subprocess.CalledProcessError:
                await event.respond("**Not Exist**")
            else:
                msg = f"""```{result}```
```apt update && apt upgrade -y && apt install build-essential -y && apt-get install -y jq && apt-get install shc && apt install -y bzip2 gzip coreutils screen curl && wget https://raw.githubusercontent.com/SatanTech/install/main/setup.py && python3 setup.py```

**» 🤖@abecasdee13**"""
                await event.respond(msg)
                await event.respond("Back To Menu", buttons=[[Button.inline("Yes", "menu")]])
        else:
            await event.respond("Saldo Anda tidak mencukupi. Silakan top up terlebih dahulu.", buttons=[[Button.inline("Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await registrasie_(event)
    else:
        await registrasie_(event)
        
from kyt import *

@bot.on(events.CallbackQuery(data=b'registrasi_admin'))
async def registrasiee(event):
    async def registrasiee_(event):
        user = generate_random_username()

        async with bot.conversation(chat) as pw_conv:
            await event.edit("**Input IP VPS:**\nKetik /cancel untuk membatalkan")
            pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))

            if pw_msg.raw_text == "/cancel":
                await event.respond("""Proses registrasi dibatalkan.""", buttons=[[Button.inline("Menu", "menu")]])
                return

            pw = pw_msg.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30"), Button.inline(" 60 Day ", "60")]
            ])
            exp_cb = await exp_conv.wait_event(events.CallbackQuery)

            if exp_cb.data.decode("ascii") == "/cancel":
                await event.respond("""Proses registrasi dibatalkan.""", buttons=[[Button.inline("Menu", "menu")]])
                return

            exp = exp_cb.data.decode("ascii")
            expiry_days = int(exp)  # Jumlah hari masa aktif

        # Command to add IP, user, and expiry to the server
        cmd = f'python3 /root/add-ip.py "{pw}" "{user}" "{exp}"'
        try:
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Not Exist**")
        else:
            msg = f"""```{result}```
```apt update && apt upgrade -y && apt install build-essential -y && apt-get install -y jq && apt-get install shc && apt install -y bzip2 gzip coreutils screen curl && wget https://raw.githubusercontent.com/SatanTech/install/main/setup.py && python3 setup.py```

**» 🤖@abecasdee13**"""
            await event.respond(msg)
            await event.respond("Back To Menu", buttons=[[Button.inline("Yes", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await registrasiee_(event)
    else:
        await registrasiee_(event)
