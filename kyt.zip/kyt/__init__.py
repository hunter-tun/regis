from telethon import *
from flask import *
from hypercorn.config import Config
import hypercorn.asyncio
import asyncio
from asgiref.wsgi import WsgiToAsgi
import datetime as DT
import requests,time,os,subprocess,re,sqlite3,random,base64,json,math,hmac, hashlib
import logging
from datetime import datetime, timedelta
import requests as req
import string
#usr/local/bin/kyt
logging.basicConfig(level=logging.INFO)
bot_start_time = DT.datetime.now()

MerchantID = 'M240729PRNLE024'
SecretKey = '9740bc47d2978fc94a417966f0ae1efad064ba8c9849fc4506a8b33d858cdde8'

LOGS = 5881666389
expiry = int(time.time() + (24*60*60)) # 24 jam
HTTP_TIMEOUT = 60
app = Flask(__name__)
aapp = WsgiToAsgi(app)
config = Config()
config.bind = ["0.0.0.0:3001"]

class TimeoutRequestsSession(requests.Session):
    def request(self, *args, **kwargs):
        kwargs.setdefault('timeout', HTTP_TIMEOUT)
        return super(TimeoutRequestsSession, self).request(*args, **kwargs)

requests = TimeoutRequestsSession()
requests.headers.update({"AUTH_KEY":"meki"})

exec(open("kyt/var.txt","r").read())
bot = TelegramClient("aginazharmhlutpi14","15995433","6fc6fd0c77e5494c14724442abe46e5e").start(bot_token=BOT_TOKEN)
try:
	open("kyt/database_regis.db")
except:
	x = sqlite3.connect("kyt/database_regis.db")
	c = x.cursor()
	c.execute('''
CREATE TABLE user (
		saldo INTEGER NOT NULL DEFAULT 0,
		member INTEGER,
		email TEXT,
		vps_ip Text,
		vps_expiry TEXT,
		created TEXT,
		counted INTEGER DEFAULT 0
		);
    ''')

	c.execute("CREATE TABLE admin (user_id INTEGER NOT NULL);")
	c.execute("INSERT INTO admin (user_id) VALUES (?)",("5881666389",))
	x.commit()

def get_db():
	x = sqlite3.connect("kyt/database_regis.db")
	x.row_factory = sqlite3.Row
	return x
	
def get_user_count():
    conn = sqlite3.connect('kyt/database_regis.db')
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM user')
    count = c.fetchone()[0]
    conn.close()
    return count

def generate_random_username(length=8):
    letters_and_digits = string.ascii_letters + string.digits
    random_part = ''.join(random.choice(letters_and_digits) for i in range(length))
    return f'SF-{random_part}'
    
def replace_vps_ip(user_id, old_ip, new_ip):
    conn = sqlite3.connect('kyt/database_regis.db')  # Ganti dengan nama database Anda
    cursor = conn.cursor()
    
    cursor.execute("SELECT vps_ip FROM user WHERE member = ?", (user_id,))
    row = cursor.fetchone()
    
    if row:
        existing_ips = row[0]
        
        if existing_ips:
            ips = existing_ips.split(',')
            
            if old_ip in ips:
                index = ips.index(old_ip)
                ips[index] = new_ip
                
                new_ips = ','.join(ips)
                
                cursor.execute("UPDATE user SET vps_ip = ? WHERE member = ?", (new_ips, user_id))
                conn.commit()
                conn.close()
                return True
    
    conn.close()
    return False
    
def renew_vps_ip(user_id, ip, additional_days):
    conn = sqlite3.connect('kyt/database_regis.db')  # Ganti dengan nama database Anda
    cursor = conn.cursor()

    cursor.execute("SELECT vps_ip, vps_expiry FROM user WHERE member = ?", (user_id,))
    row = cursor.fetchone()

    if row:
        existing_ips = row[0]
        expiry_dates = row[1]

        if existing_ips and expiry_dates:
            ips = existing_ips.split(',')
            expiries = expiry_dates.split(',')

            if ip in ips:
                index = ips.index(ip)
                current_expiry_date = datetime.strptime(expiries[index], "%Y-%m-%d")
                new_expiry_date = current_expiry_date + timedelta(days=additional_days)
                expiries[index] = new_expiry_date.strftime("%Y-%m-%d")

                new_expiries = ','.join(expiries)
                cursor.execute("UPDATE user SET vps_expiry = ? WHERE member = ?", (new_expiries, user_id))
                conn.commit()
                conn.close()
                return True

    conn.close()
    return False

def add_vps_ip(user_id, vps_ip, expiry_days):
    conn = sqlite3.connect('kyt/database_regis.db')  # Ganti dengan nama database Anda
    cursor = conn.cursor()
    expiry_date = (datetime.now() + timedelta(days=expiry_days)).strftime("%Y-%m-%d")
    
    # Periksa apakah IP sudah ada
    cursor.execute("SELECT vps_ip, vps_expiry FROM user WHERE member = ?", (user_id,))
    row = cursor.fetchone()
    
    if row:
        existing_ips = row[0]
        existing_expiries = row[1]
        
        if existing_ips:
            ip_list = existing_ips.split(',')
            if vps_ip in ip_list:
                print("IP sudah terdaftar.")
                conn.close()
                return
            
            new_ips = existing_ips + ',' + vps_ip
            new_expiries = existing_expiries + ',' + expiry_date
        else:
            new_ips = vps_ip
            new_expiries = expiry_date
        
        cursor.execute("UPDATE user SET vps_ip = ?, vps_expiry = ? WHERE member = ?", (new_ips, new_expiries, user_id))
    else:
        cursor.execute("INSERT INTO user (member, vps_ip, vps_expiry) VALUES (?, ?, ?)", (user_id, vps_ip, expiry_date))
    
    conn.commit()
    conn.close()
    
# Function to check and remove expired VPS IPs
def remove_expired_vps():
    conn = sqlite3.connect('kyt/database_regis.db')  # Ganti dengan nama database Anda
    cursor = conn.cursor()
    current_date = datetime.now().strftime("%Y-%m-%d")
    
    cursor.execute("SELECT member, vps_ip, vps_expiry FROM user")
    rows = cursor.fetchall()
    
    for row in rows:
        user_id, vps_ips, vps_expiries = row
        if vps_ips and vps_expiries:
            ips = vps_ips.split(',')
            expiries = vps_expiries.split(',')
            updated_ips = []
            updated_expiries = []
            
            for ip, expiry in zip(ips, expiries):
                if expiry > current_date:
                    updated_ips.append(ip)
                    updated_expiries.append(expiry)
            
            if updated_ips:
                new_ips = ','.join(updated_ips)
                new_expiries = ','.join(updated_expiries)
            else:
                new_ips = None
                new_expiries = None
            
            cursor.execute("UPDATE user SET vps_ip = ?, vps_expiry = ? WHERE member = ?", (new_ips, new_expiries, user_id))
    
    conn.commit()
    conn.close()

# Function to get VPS IP list for a user
def get_user_vps_ips(user_id):
    conn = sqlite3.connect('kyt/database_regis.db')  # Ganti dengan nama database Anda
    cursor = conn.cursor()
    cursor.execute("SELECT vps_ip, vps_expiry FROM user WHERE member = ?", (user_id,))
    result = cursor.fetchone()
    conn.close()
    
    if result and result[0] and result[1]:
        ips = result[0].split(',')
        expiries = result[1].split(',')
        return list(zip(ips, expiries))
    return []	
    
# Function to get the balance of the user
def get_balance(user_id):
    conn = sqlite3.connect("kyt/database_regis.db")
    c = conn.cursor()
    c.execute("SELECT saldo FROM user WHERE member = ?", (user_id,))
    result = c.fetchone()
    conn.close()
    if result:
        return result[0]
    return 0
    
def check_saldo(user_id):
    conn = sqlite3.connect('kyt/database_regis.db')
    cursor = conn.cursor()
    cursor.execute("SELECT saldo FROM user WHERE member=?", (user_id,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else 0

def update_saldo(user_id, new_saldo):
    conn = sqlite3.connect('kyt/database_regis.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE user SET saldo=? WHERE member=?", (new_saldo, user_id))
    conn.commit()
    conn.close()
        
# Function to update the balance of the user
def update_balance(user_id, new_balance):
    conn = sqlite3.connect("kyt/database_regis.db")
    c = conn.cursor()
    c.execute("UPDATE user SET saldo = ? WHERE member = ?", (new_balance, user_id))
    conn.commit()
    conn.close()

@bot.on(events.NewMessage(pattern=r"(?:.start|start|/start)$"))
async def free(event):
    sender = await event.get_sender()
    if not sender.username:
        await event.reply("**Anda harus memiliki nama pengguna untuk mendaftar!**")
        return

    async def free_(event):
        email = str(sender.username) + "@sfvt.net"
        db.execute("INSERT INTO user (saldo, member, email) VALUES (?,?,?)",("0", sender.id, email,))
        db.commit()
        await event.reply(f"""
**━━━━━━━━━━━━━━━━**
**🔰 Sukses Terdaftar 🔰**
**━━━━━━━━━━━━━━━━**
**👤 Member Information :**
**🔰 💌 Email :** `{sender.username}@sfvt.net`
**🔰 🆔 Member Id :** `{sender.id}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
""", buttons=[[Button.inline(" MENU ", "menu")]])

    val = valid(sender.id)
    db = get_db()
    x = db.execute("SELECT * FROM admin").fetchall()
    a = [v[0] for v in x]
    if sender.id not in a and val == "false":
            await free_(event)
    else:
        await event.reply(f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
       ** 🔰 SELAMAT DATANG 🔰**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**👤 Member Information :**
**🔰 💌 Email :** `{sender.username}@sfvt.net`
**🔰 🆔 Member Id :** `{sender.id}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
""", buttons=[[Button.inline(" MENU ", "menu")]])

def valid(id):
	db = get_db()
	x = db.execute("SELECT saldo, member, email FROM user WHERE member = (?)",(id,)).fetchone()
	if not x:
		return "false"
	else:
		return {"saldo":x[0],"member":x[1],"email":x[2]}

def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])
   
@bot.on(events.NewMessage(pattern="(?:/bcast)"))
async def bcast(event):
    db = get_db()
    memberz = [x[0] for x in db.execute("SELECT member FROM user").fetchall()]
    
    async def bcast_(event, res):
        if event.is_reply:
            msg = await event.get_reply_message()
            try:
                await bot.send_message(res, msg)  # Menggunakan 'bot' sebagai klien untuk mengirim pesan
                return True  # Berhasil mengirim pesan
            except Exception as e:
                print(f"Broadcast ke user {res} gagal: {e}")
                return False  # Gagal mengirim pesan

        else:
            await event.respond("**Reply To Message, File, Media, Images, Or Sticker!**")
            return False  # Gagal mengirim pesan karena tidak ada pesan balasan

    x = db.execute("SELECT user_id FROM admin").fetchall()
    a = [v[0] for v in x]
    sender = await event.get_sender()
    if sender.id in a:
        if event.is_reply:
            msg = await event.get_reply_message()
            success_count = 0
            for res in memberz:
                success = await bcast_(event, res)
                if success:
                    success_count += 1
            
            await event.respond(f"**Berhasil Broadcast ke** `{str(success_count)}/{str(len(memberz))}` **Member**")
        else:
            await event.respond("**Reply To Message, File, Media, Images, Or Sticker!**")
    else:
        await event.respond("**Akses Ditolak**")
   